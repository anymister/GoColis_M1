<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier contient les réglages de configuration suivants : réglages MySQL,
 * préfixe de table, clés secrètes, langue utilisée, et ABSPATH.
 * Vous pouvez en savoir plus à leur sujet en allant sur
 * {@link http://codex.wordpress.org/fr:Modifier_wp-config.php Modifier
 * wp-config.php}. C’est votre hébergeur qui doit vous donner vos
 * codes MySQL.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en "wp-config.php" et remplir les
 * valeurs.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'id12899089_bd_gocolis' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'id12899089_bd_user_gocolis' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', 'n*vpM^u\\$+nwdtx2' );

/** Adresse de l’hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Type de collation de la base de données.
  * N’y touchez que si vous savez ce que vous faites.
  */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clefs secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Py=9?DFK]Yz&O0`d}WOn%/6m|Yv!aaD@O+c;a A>XjlI`A^F=o~CaJ~/%-a-2R|]' );
define( 'SECURE_AUTH_KEY',  '}q}b3MZwBm1=CEF_/iLFg%t/E1]bM(ba9]J:Z:>x N)TeUq^_8pyAsMyT_U^*/()' );
define( 'LOGGED_IN_KEY',    'qq_t9y-dc1w~Ft]1^$ppP&ETWgmtwGy{;#t5E>uVx`<[2y*1GzE>NF*n;- a _lb' );
define( 'NONCE_KEY',        '[2u4W+&0lb)~O<tSMn5A1jFtc2&]FuA@.+.A|h?|dL1m(J.*#3GwTX6Hez>meMtK' );
define( 'AUTH_SALT',        'ThxRW7D%kB}~gn-S09{&.2q6 #_$<M+Ec;kqQ0=BvS+6`_%@t1|_i-b32lO+Ta+p' );
define( 'SECURE_AUTH_SALT', '7AiABS+3&R/>?Bj..EL3LZb!C_J>Um7@[KG=r}qc;Ro;ztP8ET*[I-I2$nUbuP[7' );
define( 'LOGGED_IN_SALT',   'A]~_MMFAT@V(B/%wV(PkRRf7+Z{duE9ty9nJO0z(,X-LZT/@WFy |]G!96.Uu^q8' );
define( 'NONCE_SALT',       'Adn+{w-l;R{fq[WxS6o[W`= z|wQc}*DxU,&X9u5j8eo0r41}Gi{|vE9sL<E)~!v' );
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'wp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortemment recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
